#pragma once
#include "Scene.h"
class Scene1 : public Scene
{
	void init() override;
};

