#pragma once
#include "Scene.h"
class Scene0 : public Scene
{
	void init() override;
};

