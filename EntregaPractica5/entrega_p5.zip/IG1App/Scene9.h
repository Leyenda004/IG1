#pragma once
#include "Scene.h"
class Scene9 :
    public Scene
{
    void init() override;
};
