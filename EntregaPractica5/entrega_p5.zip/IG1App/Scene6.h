#pragma once
#include "Scene.h"

class Scene6 : public Scene
{
public:
    void init() override;
};