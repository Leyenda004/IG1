#pragma once
#include "Scene.h"
class Scene6 :
    public Scene
{
    void init() override;
};

