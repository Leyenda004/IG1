#pragma once
#include "Scene.h"
class Scene5 :
    public Scene
{
    void init() override;
};

