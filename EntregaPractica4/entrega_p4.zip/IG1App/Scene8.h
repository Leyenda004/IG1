#pragma once
#include "Scene.h"

class CompoundEntity;

class Scene8 : public Scene
{
public:
    void init() override;
};
