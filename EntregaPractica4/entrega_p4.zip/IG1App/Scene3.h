#pragma once
#include "Scene.h"
class Scene3 :
    public Scene
{
    void init() override;
};

