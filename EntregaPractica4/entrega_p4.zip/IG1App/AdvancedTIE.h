#pragma once
#include "CompoundEntity.h"
class AdvancedTIE :
    public CompoundEntity
{
public:
	AdvancedTIE();
	~AdvancedTIE() {};
};

