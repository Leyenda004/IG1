#pragma once
#include "ColorMaterialEntity.h"
class IndexedBox :
    public ColorMaterialEntity
{
public:
    IndexedBox(float l);
};

