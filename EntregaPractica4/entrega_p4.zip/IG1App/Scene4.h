#pragma once
#include "Scene.h"
class Scene4 :
    public Scene
{
    void init() override;
};

