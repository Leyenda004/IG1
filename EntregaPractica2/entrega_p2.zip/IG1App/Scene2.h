#pragma once
#include "Scene.h"
class Scene2 :
    public Scene
{
    void init() override;
};